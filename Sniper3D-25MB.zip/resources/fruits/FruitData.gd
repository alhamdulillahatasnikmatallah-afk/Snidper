extends Resource
class_name FruitData

@export var id: String = "apple"
@export var display_name: String = "Apple"
@export var mass: float = 0.25
@export var radius: float = 0.12
@export var color: Color = Color(0.85, 0.15, 0.12)
@export var impulse_multiplier: float = 1.0
@export var bounce: float = 0.3
@export var breakable: bool = false
@export var health: float = 1.0
@export var score_value: int = 100
