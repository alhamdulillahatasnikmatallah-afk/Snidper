extends Resource
class_name RankData

@export var id: String = "THE_COOK"
@export var display_name: String = "THE COOK"
@export var difficulty: String = "Easy"
@export var description: String = "Hit apples and oranges."
@export var required_hits: int = 10
@export var time_limit: float = 90.0
@export var accuracy_required: float = 60.0
@export var fruit_types: Array[String] = ["apple", "orange"]
@export var unlocked: bool = true
@export var color: Color = Color(1.0, 0.7, 0.2)
