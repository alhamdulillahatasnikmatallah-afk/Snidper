Models included (lightweight for <25MB zip):

- weapons/barrett/  → Barrett.FBX, Barrett.3DS, texture
- hand/             → Rigged Hand.3ds + textures
- grass/            → Grass1.jpg, Grass2.jpg (textures only)

Removed from package (too large for GitHub web upload):
- Male.OBJ (45MB high-poly)
- Scene_Morning.blend, Grass.blend

Game still runs fully with procedural fruits + CSG weapon fallback.
