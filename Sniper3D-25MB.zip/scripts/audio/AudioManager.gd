extends Node

## Centralized Audio Manager - Autoload

var _players: Array[AudioStreamPlayer] = []
var _ambient_player: AudioStreamPlayer = null
var _pool_size := 8
var _streams: Dictionary = {}

const SFX_PATHS := {
	"sniper_shot": "res://assets/audio/weapon/sniper_shot.ogg",
	"sniper_shot_var1": "res://assets/audio/weapon/sniper_shot_var1.ogg",
	"bolt_action": "res://assets/audio/weapon/bolt_action.ogg",
	"reload": "res://assets/audio/weapon/reload.ogg",
	"scope_open": "res://assets/audio/scope/scope_open.ogg",
	"scope_close": "res://assets/audio/scope/scope_close.ogg",
	"fruit_hit": "res://assets/audio/impact/fruit_hit.ogg",
	"apple_hit": "res://assets/audio/impact/apple_hit.ogg",
	"watermelon_break": "res://assets/audio/impact/watermelon_break.ogg",
	"button_click": "res://assets/audio/ui/button_click.ogg",
	"hit_marker": "res://assets/audio/ui/hit_marker.ogg",
	"perfect_hit": "res://assets/audio/ui/perfect_hit.ogg",
}

const AMBIENT_PATHS := {
	"wind": "res://assets/audio/env/wind_loop.ogg",
	"birds": "res://assets/audio/env/birds_loop.ogg",
}

func _ready() -> void:
	for i in range(_pool_size):
		var p := AudioStreamPlayer.new()
		p.bus = "Master"
		add_child(p)
		_players.append(p)
	
	_ambient_player = AudioStreamPlayer.new()
	_ambient_player.bus = "Master"
	_ambient_player.volume_db = -12.0
	add_child(_ambient_player)
	
	for key in SFX_PATHS:
		var path = SFX_PATHS[key]
		if ResourceLoader.exists(path):
			_streams[key] = load(path)
	
	for key in AMBIENT_PATHS:
		var path = AMBIENT_PATHS[key]
		if ResourceLoader.exists(path):
			_streams[key] = load(path)
	
	print("[AudioManager] Ready. Loaded %d sounds." % _streams.size())

func play_sfx(key: String, volume_db: float = 0.0, pitch_scale: float = 1.0) -> void:
	if not _streams.has(key):
		return
	var player := _get_free_player()
	if player == null:
		return
	player.stream = _streams[key]
	player.volume_db = volume_db
	player.pitch_scale = pitch_scale + randf_range(-0.04, 0.04)
	player.play()

func play_ui(key: String) -> void:
	play_sfx(key, -3.0)

func play_weapon(key: String) -> void:
	play_sfx(key, 0.0)

func play_impact(key: String, position: Vector3 = Vector3.ZERO) -> void:
	play_sfx(key, -2.0)

func play_ambient(key: String = "wind", loop: bool = true) -> void:
	if not _streams.has(key) or _ambient_player == null:
		return
	_ambient_player.stream = _streams[key]
	if _ambient_player.stream is AudioStreamOggVorbis:
		(_ambient_player.stream as AudioStreamOggVorbis).loop = loop
	_ambient_player.play()

func stop_ambient() -> void:
	if _ambient_player:
		_ambient_player.stop()

func set_bus_volume(bus_name: String, linear: float) -> void:
	var idx = AudioServer.get_bus_index(bus_name)
	if idx >= 0:
		AudioServer.set_bus_volume_db(idx, linear_to_db(clampf(linear, 0.0, 1.0)))

func _get_free_player() -> AudioStreamPlayer:
	for p in _players:
		if not p.playing:
			return p
	return _players[0] if _players.size() > 0 else null
