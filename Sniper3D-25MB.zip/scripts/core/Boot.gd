extends Control

@onready var progress: ProgressBar = $Center/ProgressBar
@onready var tip: Label = $Center/Tip

var tips := [
	"Tembak tepat di tengah untuk skor maksimal",
	"Gunakan scope 8x untuk target jauh",
	"Combo tinggi = multiplier skor lebih besar",
	"Watermelon lebih berat, impuls lebih kecil",
	"Mode Rank butuh akurasi tinggi"
]

func _ready() -> void:
	GameManager.change_state(GameManager.GameState.BOOT)
	tip.text = tips[randi() % tips.size()]
	_start_loading()

func _start_loading() -> void:
	# Simulate loading steps
	var steps := [
		{"msg": "Loading systems...", "val": 15},
		{"msg": "Loading weapons...", "val": 35},
		{"msg": "Loading fruits...", "val": 55},
		{"msg": "Loading audio...", "val": 75},
		{"msg": "Preparing range...", "val": 90},
		{"msg": "Ready!", "val": 100}
	]
	
	for step in steps:
		progress.value = step.val
		await get_tree().create_timer(0.35).timeout
	
	# Go to home
	await get_tree().create_timer(0.2).timeout
	_go_home()

func _go_home() -> void:
	GameManager.change_state(GameManager.GameState.HOME)
	# Change to home scene
	get_tree().change_scene_to_file("res://scenes/menus/home.tscn")
