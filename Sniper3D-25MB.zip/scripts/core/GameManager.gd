extends Node

## Global Game Manager - Autoload
## Handles game state, mode switching, and high-level flow.

enum GameState {
	BOOT,
	LOADING,
	HOME,
	MODE_SELECT,
	WEAPON_MENU,
	RANK_MENU,
	SETTINGS,
	PLAYING,
	RESULT,
	PAUSED
}

enum GameMode {
	NONE,
	TIME,
	FREE,
	RANK
}

signal state_changed(new_state: GameState)
signal mode_changed(new_mode: GameMode)
signal score_updated(score: int)
signal mission_completed(result: Dictionary)

var current_state: GameState = GameState.BOOT
var current_mode: GameMode = GameMode.NONE
var current_rank: String = ""

var player_data := {
	"name": "SniperX",
	"level": 12,
	"xp": 2450,
	"xp_to_next": 3000,
	"coins": 12650,
	"gems": 320,
	"energy": 10,
	"max_energy": 10,
	"selected_weapon": "sniper_basic",
	"unlocked_ranks": ["THE_COOK"],
	"best_scores": {},
	"settings": {}
}

var session_score: int = 0
var session_hits: int = 0
var session_misses: int = 0
var session_combo: int = 0
var session_best_combo: int = 0
var session_accuracy: float = 0.0
var session_time_left: float = 0.0

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	print("[GameManager] Initialized")

func change_state(new_state: GameState) -> void:
	if current_state == new_state:
		return
	var old = current_state
	current_state = new_state
	print("[GameManager] State: ", GameState.keys()[old], " -> ", GameState.keys()[new_state])
	state_changed.emit(new_state)

func start_mode(mode: GameMode, rank: String = "") -> void:
	current_mode = mode
	current_rank = rank
	session_score = 0
	session_hits = 0
	session_misses = 0
	session_combo = 0
	session_best_combo = 0
	session_accuracy = 0.0
	mode_changed.emit(mode)
	change_state(GameState.PLAYING)

func add_score(points: int) -> void:
	session_score += points
	score_updated.emit(session_score)

func register_hit(is_perfect: bool = false) -> void:
	session_hits += 1
	session_combo += 1
	if session_combo > session_best_combo:
		session_best_combo = session_combo
	_update_accuracy()

func register_miss() -> void:
	session_misses += 1
	session_combo = 0
	_update_accuracy()

func _update_accuracy() -> void:
	var total = session_hits + session_misses
	if total > 0:
		session_accuracy = float(session_hits) / float(total) * 100.0
	else:
		session_accuracy = 0.0

func end_mission() -> Dictionary:
	var result := {
		"score": session_score,
		"hits": session_hits,
		"misses": session_misses,
		"accuracy": session_accuracy,
		"best_combo": session_best_combo,
		"mode": current_mode,
		"rank": current_rank
	}
	mission_completed.emit(result)
	change_state(GameState.RESULT)
	return result

func go_home() -> void:
	current_mode = GameMode.NONE
	current_rank = ""
	change_state(GameState.HOME)

func get_player_level_progress() -> float:
	if player_data.xp_to_next <= 0:
		return 1.0
	return float(player_data.xp) / float(player_data.xp_to_next)
