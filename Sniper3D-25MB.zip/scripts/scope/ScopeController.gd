extends Node
class_name ScopeController

## Smooth scope system with multiple zoom levels.
## Works with Camera3D and WeaponController.

signal scope_opened
signal scope_closed
signal zoom_changed(level: int)

@export var camera_path: NodePath
@export var normal_fov: float = 70.0
@export var zoom_fovs: Array[float] = [70.0, 45.0, 28.0, 14.0]  # 1x 2x 4x 8x
@export var transition_time: float = 0.28
@export var hold_to_scope: bool = false

var camera: Camera3D
var is_scoped: bool = false
var current_zoom_index: int = 0
var target_fov: float = 70.0
var transition_progress: float = 1.0
var start_fov: float = 70.0

func _ready() -> void:
	if camera_path:
		camera = get_node_or_null(camera_path)
	if camera == null:
		camera = get_viewport().get_camera_3d()
	
	if camera:
		normal_fov = camera.fov
		target_fov = normal_fov

func _process(delta: float) -> void:
	if camera == null:
		return
	if transition_progress < 1.0:
		transition_progress = minf(transition_progress + delta / transition_time, 1.0)
		var t = _ease_out_cubic(transition_progress)
		camera.fov = lerpf(start_fov, target_fov, t)

func toggle_scope() -> void:
	if is_scoped:
		close_scope()
	else:
		open_scope()

func open_scope() -> void:
	if is_scoped:
		return
	is_scoped = true
	start_fov = camera.fov if camera else normal_fov
	target_fov = zoom_fovs[current_zoom_index]
	transition_progress = 0.0
	scope_opened.emit()
	AudioManager.play_sfx("scope_open")

func close_scope() -> void:
	if not is_scoped:
		return
	is_scoped = false
	start_fov = camera.fov if camera else target_fov
	target_fov = normal_fov
	transition_progress = 0.0
	scope_closed.emit()
	AudioManager.play_sfx("scope_close")

func set_zoom_level(index: int) -> void:
	index = clampi(index, 0, zoom_fovs.size() - 1)
	if index == current_zoom_index:
		return
	current_zoom_index = index
	if is_scoped:
		start_fov = camera.fov if camera else target_fov
		target_fov = zoom_fovs[current_zoom_index]
		transition_progress = 0.0
	zoom_changed.emit(current_zoom_index)
	AudioManager.play_sfx("zoom_change")

func cycle_zoom() -> void:
	var next = (current_zoom_index + 1) % zoom_fovs.size()
	set_zoom_level(next)

func get_current_zoom_multiplier() -> float:
	match current_zoom_index:
		0: return 1.0
		1: return 2.0
		2: return 4.0
		3: return 8.0
		_: return 1.0

func _ease_out_cubic(x: float) -> float:
	return 1.0 - pow(1.0 - x, 3.0)
