extends Node

## Quality & Performance Manager - Autoload

enum QualityPreset {
	LOW,
	MEDIUM,
	HIGH
}

signal quality_changed(preset: QualityPreset)

var current_preset: QualityPreset = QualityPreset.MEDIUM

var settings := {
	"render_scale": 0.85,
	"shadows": true,
	"particles": true,
	"anti_aliasing": true,
	"post_processing": true,
	"effects_density": 1.0,
	"fps_display": false
}

func _ready() -> void:
	# Auto-detect on first run if possible
	if not GameManager.player_data.settings.has("quality"):
		_auto_detect_quality()
	else:
		var saved = GameManager.player_data.settings.get("quality", "MEDIUM")
		match saved:
			"LOW":
				set_quality(QualityPreset.LOW)
			"HIGH":
				set_quality(QualityPreset.HIGH)
			_:
				set_quality(QualityPreset.MEDIUM)

func set_quality(preset: QualityPreset) -> void:
	current_preset = preset
	match preset:
		QualityPreset.LOW:
			settings.render_scale = 0.55
			settings.shadows = false
			settings.particles = false
			settings.anti_aliasing = false
			settings.post_processing = false
			settings.effects_density = 0.4
		QualityPreset.MEDIUM:
			settings.render_scale = 0.75
			settings.shadows = true
			settings.particles = true
			settings.anti_aliasing = false
			settings.post_processing = true
			settings.effects_density = 0.7
		QualityPreset.HIGH:
			settings.render_scale = 1.0
			settings.shadows = true
			settings.particles = true
			settings.anti_aliasing = true
			settings.post_processing = true
			settings.effects_density = 1.0
	
	_apply_settings()
	quality_changed.emit(preset)
	
	# Persist
	GameManager.player_data.settings["quality"] = QualityPreset.keys()[preset]
	SaveManager.save_game()

func _apply_settings() -> void:
	# Apply render scale
	get_tree().root.content_scale_factor = settings.render_scale
	
	# Note: Further graphics tweaks (shadows, MSAA, etc.) 
	# should be applied via WorldEnvironment and Viewport settings
	# in the active scene / Camera3D / Environment resource.
	print("[QualityManager] Applied preset: ", QualityPreset.keys()[current_preset])

func _auto_detect_quality() -> void:
	# Simple heuristic - on real device use OS.get_processor_count() + memory
	var cores := OS.get_processor_count()
	if cores <= 4:
		set_quality(QualityPreset.LOW)
	elif cores <= 6:
		set_quality(QualityPreset.MEDIUM)
	else:
		set_quality(QualityPreset.HIGH)

func get_render_scale() -> float:
	return settings.render_scale
