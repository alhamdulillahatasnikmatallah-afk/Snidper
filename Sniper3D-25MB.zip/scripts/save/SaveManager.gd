extends Node

## Save / Load Manager - Autoload
## Uses ConfigFile for local persistent storage.

const SAVE_PATH := "user://sniper3d_save.cfg"
const SAVE_SECTION := "player"

var is_loaded: bool = false

func _ready() -> void:
	load_game()

func save_game() -> void:
	var config := ConfigFile.new()
	var data = GameManager.player_data
	
	config.set_value(SAVE_SECTION, "name", data.name)
	config.set_value(SAVE_SECTION, "level", data.level)
	config.set_value(SAVE_SECTION, "xp", data.xp)
	config.set_value(SAVE_SECTION, "xp_to_next", data.xp_to_next)
	config.set_value(SAVE_SECTION, "coins", data.coins)
	config.set_value(SAVE_SECTION, "gems", data.gems)
	config.set_value(SAVE_SECTION, "energy", data.energy)
	config.set_value(SAVE_SECTION, "max_energy", data.max_energy)
	config.set_value(SAVE_SECTION, "selected_weapon", data.selected_weapon)
	config.set_value(SAVE_SECTION, "unlocked_ranks", data.unlocked_ranks)
	config.set_value(SAVE_SECTION, "best_scores", data.best_scores)
	config.set_value(SAVE_SECTION, "settings", data.settings)
	
	var err := config.save(SAVE_PATH)
	if err == OK:
		print("[SaveManager] Game saved successfully")
	else:
		push_error("[SaveManager] Failed to save: " + str(err))

func load_game() -> void:
	var config := ConfigFile.new()
	var err := config.load(SAVE_PATH)
	
	if err != OK:
		print("[SaveManager] No save found, using defaults")
		is_loaded = true
		return
	
	var data = GameManager.player_data
	data.name = config.get_value(SAVE_SECTION, "name", data.name)
	data.level = config.get_value(SAVE_SECTION, "level", data.level)
	data.xp = config.get_value(SAVE_SECTION, "xp", data.xp)
	data.xp_to_next = config.get_value(SAVE_SECTION, "xp_to_next", data.xp_to_next)
	data.coins = config.get_value(SAVE_SECTION, "coins", data.coins)
	data.gems = config.get_value(SAVE_SECTION, "gems", data.gems)
	data.energy = config.get_value(SAVE_SECTION, "energy", data.energy)
	data.max_energy = config.get_value(SAVE_SECTION, "max_energy", data.max_energy)
	data.selected_weapon = config.get_value(SAVE_SECTION, "selected_weapon", data.selected_weapon)
	data.unlocked_ranks = config.get_value(SAVE_SECTION, "unlocked_ranks", data.unlocked_ranks)
	data.best_scores = config.get_value(SAVE_SECTION, "best_scores", data.best_scores)
	data.settings = config.get_value(SAVE_SECTION, "settings", data.settings)
	
	is_loaded = true
	print("[SaveManager] Game loaded successfully")

func reset_save() -> void:
	var dir := DirAccess.open("user://")
	if dir and dir.file_exists("sniper3d_save.cfg"):
		dir.remove("sniper3d_save.cfg")
	print("[SaveManager] Save reset")
