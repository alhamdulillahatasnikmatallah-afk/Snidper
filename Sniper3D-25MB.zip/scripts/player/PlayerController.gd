extends Node3D
class_name PlayerController

## First-person player controller for mobile sniper.
## Owns look, integrates CharacterController + Weapon + Scope.

@export var mouse_sensitivity: float = 0.15
@export var touch_sensitivity: float = 0.12
@export var ads_sensitivity_multiplier: float = 0.42
@export var max_pitch: float = 82.0
@export var min_pitch: float = -82.0
@export var look_smoothing: float = 18.0

@onready var camera: Camera3D = $Camera3D
@onready var character: CharacterController = null
@onready var weapon: WeaponController = null
@onready var scope: ScopeController = null

var pitch: float = 0.0
var yaw: float = 0.0
var target_pitch: float = 0.0
var target_yaw: float = 0.0
var is_scoped: bool = false
var current_sensitivity: float = 0.12

var touch_start: Vector2 = Vector2.ZERO
var is_dragging: bool = false

func _ready() -> void:
	current_sensitivity = touch_sensitivity
	add_to_group("player")
	
	# Create character controller
	character = CharacterController.new()
	character.name = "CharacterController"
	add_child(character)
	
	# Create scope controller
	scope = ScopeController.new()
	scope.name = "ScopeController"
	add_child(scope)
	if camera:
		scope.camera = camera
	
	_setup_weapon()
	
	if OS.has_feature("editor") or OS.get_name() in ["Windows", "Linux", "macOS"]:
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

func _setup_weapon() -> void:
	weapon = WeaponController.new()
	weapon.name = "Weapon"
	var data = WeaponData.new()
	data.id = "sniper_basic"
	data.display_name = "M24 Sniper"
	data.magazine_size = 5
	data.reserve_ammo = 25
	data.bolt_action = true
	weapon.weapon_data = data
	
	if character and character.get_weapon_holder():
		character.get_weapon_holder().add_child(weapon)
	else:
		var holder = Node3D.new()
		holder.name = "WeaponHolder"
		holder.position = Vector3(0.22, -0.18, -0.35)
		add_child(holder)
		holder.add_child(weapon)
	
	# Visual placeholder
	var body = CSGBox3D.new()
	body.size = Vector3(0.07, 0.11, 1.15)
	body.position = Vector3(0, 0, -0.55)
	weapon.add_child(body)
	
	var scope_vis = CSGCylinder3D.new()
	scope_vis.radius = 0.045
	scope_vis.height = 0.32
	scope_vis.position = Vector3(0, 0.09, -0.28)
	weapon.add_child(scope_vis)

func _input(event: InputEvent) -> void:
	if GameManager.current_state != GameManager.GameState.PLAYING:
		return
	
	if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		_apply_look_raw(event.relative * mouse_sensitivity)
	
	if event is InputEventScreenTouch:
		if event.pressed:
			touch_start = event.position
			is_dragging = true
		else:
			is_dragging = false
	
	if event is InputEventScreenDrag and is_dragging:
		var sens = current_sensitivity
		if is_scoped:
			sens *= ads_sensitivity_multiplier
		_apply_look_raw(event.relative * sens)

func _process(delta: float) -> void:
	pitch = lerpf(pitch, target_pitch, delta * look_smoothing)
	yaw = lerpf(yaw, target_yaw, delta * look_smoothing)
	
	rotation_degrees.y = yaw
	if camera:
		camera.rotation_degrees.x = pitch

func _apply_look_raw(relative: Vector2) -> void:
	target_yaw -= relative.x
	target_pitch -= relative.y
	target_pitch = clampf(target_pitch, min_pitch, max_pitch)

func set_scoped(scoped: bool) -> void:
	is_scoped = scoped
	if scope:
		if scoped:
			scope.open_scope()
		else:
			scope.close_scope()
	current_sensitivity = touch_sensitivity * (ads_sensitivity_multiplier if scoped else 1.0)

func fire() -> void:
	if weapon:
		weapon.try_fire()

func reload() -> void:
	if weapon:
		weapon.start_reload()

func cycle_zoom() -> void:
	if scope and is_scoped:
		scope.cycle_zoom()

func get_aim_direction() -> Vector3:
	if camera:
		return -camera.global_transform.basis.z
	return -global_transform.basis.z

func get_camera() -> Camera3D:
	return camera
