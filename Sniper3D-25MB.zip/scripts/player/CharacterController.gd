extends Node3D
class_name CharacterController

## First-person character presentation (procedural fallback).

signal stance_changed(is_crouching: bool)

@export var camera_height_standing: float = 1.6
@export var camera_height_crouching: float = 1.05
@export var transition_speed: float = 8.0

var is_crouching: bool = false
var target_height: float = 1.6
var current_height: float = 1.6
var breath_time: float = 0.0
var breath_intensity: float = 1.0
var weapon_holder: Node3D = null

func _ready() -> void:
	target_height = camera_height_standing
	current_height = camera_height_standing
	
	weapon_holder = Node3D.new()
	weapon_holder.name = "WeaponHolder"
	weapon_holder.position = Vector3(0.22, -0.18, -0.35)
	add_child(weapon_holder)

func _process(delta: float) -> void:
	_update_height(delta)
	_update_breathing(delta)

func set_crouching(crouch: bool) -> void:
	if is_crouching == crouch:
		return
	is_crouching = crouch
	target_height = camera_height_crouching if crouch else camera_height_standing
	stance_changed.emit(is_crouching)

func toggle_crouch() -> void:
	set_crouching(not is_crouching)

func _update_height(delta: float) -> void:
	current_height = lerpf(current_height, target_height, delta * transition_speed)
	position.y = current_height

func _update_breathing(delta: float) -> void:
	breath_time += delta
	# subtle

func set_breathing_intensity(value: float) -> void:
	breath_intensity = clampf(value, 0.0, 2.0)

func get_weapon_holder() -> Node3D:
	return weapon_holder
