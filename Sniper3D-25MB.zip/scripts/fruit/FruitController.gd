extends RigidBody3D
class_name FruitController

## Improved fruit with type-based physics and visual

@export var fruit_type: String = "apple"
@export var mass_override: float = 0.3
@export var impact_multiplier: float = 1.0
@export var fruit_color: Color = Color(0.85, 0.15, 0.12)
@export var fruit_radius: float = 0.12
@export var breakable: bool = false

var is_hit: bool = false
var health: float = 1.0
var mesh_instance: MeshInstance3D
var collision: CollisionShape3D

func _ready() -> void:
	mass = mass_override
	gravity_scale = 1.0
	continuous_cd = true
	contact_monitor = true
	max_contacts_reported = 4
	collision_layer = 2
	collision_mask = 1 | 2
	_build_visual()

func _build_visual() -> void:
	# Clear old
	for c in get_children():
		c.queue_free()
	
	var mesh := SphereMesh.new()
	mesh.radius = fruit_radius
	mesh.height = fruit_radius * 2.0
	
	mesh_instance = MeshInstance3D.new()
	mesh_instance.mesh = mesh
	var mat := StandardMaterial3D.new()
	mat.albedo_color = fruit_color
	mat.roughness = 0.45
	mesh_instance.material_override = mat
	add_child(mesh_instance)
	
	collision = CollisionShape3D.new()
	var shape := SphereShape3D.new()
	shape.radius = fruit_radius
	collision.shape = shape
	add_child(collision)

func apply_bullet_impact(direction: Vector3, force: float = 5.0) -> void:
	if is_hit and not breakable:
		return
	is_hit = true
	health -= 1.0
	
	var impulse = direction.normalized() * force * impact_multiplier
	apply_impulse(impulse)
	apply_torque_impulse(Vector3(randf_range(-1.2, 1.2), randf_range(-1.2, 1.2), randf_range(-1.2, 1.2)) * 1.1)
	
	if breakable and health <= 0:
		_break_fruit()
	else:
		# slight squash visual
		if mesh_instance:
			var tw = create_tween()
			tw.tween_property(mesh_instance, "scale", Vector3(1.15, 0.85, 1.15), 0.06)
			tw.tween_property(mesh_instance, "scale", Vector3.ONE, 0.12)

func _break_fruit() -> void:
	# Simple break: hide + small particles via scale
	if mesh_instance:
		var tw = create_tween()
		tw.tween_property(mesh_instance, "scale", Vector3(1.4, 1.4, 1.4), 0.08)
		tw.tween_property(mesh_instance, "scale", Vector3.ZERO, 0.15)
		tw.tween_callback(queue_free)
	AudioManager.play_impact("watermelon_break")

func setup_from_type(type: String) -> void:
	fruit_type = type
	match type:
		"apple":
			mass_override = 0.25
			fruit_radius = 0.11
			fruit_color = Color(0.85, 0.12, 0.1)
			impact_multiplier = 1.1
			breakable = false
		"orange":
			mass_override = 0.28
			fruit_radius = 0.13
			fruit_color = Color(1.0, 0.55, 0.1)
			impact_multiplier = 1.0
			breakable = false
		"pear":
			mass_override = 0.3
			fruit_radius = 0.12
			fruit_color = Color(0.7, 0.85, 0.25)
			impact_multiplier = 0.95
			breakable = false
		"watermelon":
			mass_override = 1.8
			fruit_radius = 0.28
			fruit_color = Color(0.15, 0.55, 0.2)
			impact_multiplier = 0.55
			breakable = true
			health = 2.0
		"melon":
			mass_override = 1.2
			fruit_radius = 0.22
			fruit_color = Color(0.95, 0.75, 0.35)
			impact_multiplier = 0.7
			breakable = true
		"coconut":
			mass_override = 1.4
			fruit_radius = 0.15
			fruit_color = Color(0.45, 0.28, 0.12)
			impact_multiplier = 0.4
			breakable = false
	mass = mass_override
	_build_visual()
