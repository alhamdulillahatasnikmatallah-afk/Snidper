extends Node3D
class_name FruitSpawner

## Spawns fruits for the current mode

signal fruit_spawned(fruit: FruitController)
signal all_fruits_cleared

@export var spawn_points: Array[Vector3] = [
	Vector3(0, 1.1, -8.2),
	Vector3(1.5, 1.1, -10),
	Vector3(-1.8, 1.1, -12),
	Vector3(0.8, 1.3, -15),
	Vector3(-1.0, 1.2, -9.5)
]

var active_fruits: Array[FruitController] = []
var spawn_index: int = 0

func spawn_fruit(type: String = "apple") -> FruitController:
	var fruit = FruitController.new()
	fruit.name = "Fruit_%s_%d" % [type, spawn_index]
	fruit.setup_from_type(type)
	
	var pos = spawn_points[spawn_index % spawn_points.size()]
	# slight random offset
	pos += Vector3(randf_range(-0.3, 0.3), 0, randf_range(-0.4, 0.4))
	fruit.position = pos
	add_child(fruit)
	active_fruits.append(fruit)
	spawn_index += 1
	fruit_spawned.emit(fruit)
	return fruit

func spawn_sequence(types: Array[String], count: int) -> void:
	clear_all()
	for i in range(count):
		var t = types[i % types.size()]
		spawn_fruit(t)
		await get_tree().create_timer(0.05).timeout

func clear_all() -> void:
	for f in active_fruits:
		if is_instance_valid(f):
			f.queue_free()
	active_fruits.clear()
	spawn_index = 0

func get_active_count() -> int:
	var c = 0
	for f in active_fruits:
		if is_instance_valid(f) and not f.is_hit:
			c += 1
	return c
