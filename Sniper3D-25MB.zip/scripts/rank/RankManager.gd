extends Node
class_name RankManager

## Manages rank progression data

const RANKS := [
	{
		"id": "THE_COOK",
		"name": "THE COOK",
		"difficulty": "Easy",
		"desc": "Hit 10 apples & oranges",
		"hits": 10,
		"time": 90.0,
		"accuracy": 60.0,
		"fruits": ["apple", "orange"],
		"color": Color(1.0, 0.7, 0.2)
	},
	{
		"id": "THE_CHICKEN",
		"name": "THE CHICKEN",
		"difficulty": "Normal",
		"desc": "Hit 15 mixed fruits",
		"hits": 15,
		"time": 75.0,
		"accuracy": 70.0,
		"fruits": ["apple", "orange", "pear"],
		"color": Color(1.0, 0.85, 0.3)
	},
	{
		"id": "THE_COOL",
		"name": "THE COOL",
		"difficulty": "Hard",
		"desc": "Hit 20 mixed + watermelon",
		"hits": 20,
		"time": 60.0,
		"accuracy": 78.0,
		"fruits": ["apple", "orange", "watermelon", "melon"],
		"color": Color(0.3, 0.6, 1.0)
	},
	{
		"id": "THE_MASTER",
		"name": "THE MASTER",
		"difficulty": "Very Hard",
		"desc": "Hit 25 targets, high accuracy",
		"hits": 25,
		"time": 50.0,
		"accuracy": 85.0,
		"fruits": ["apple", "orange", "pear", "watermelon", "melon"],
		"color": Color(0.6, 0.3, 0.9)
	},
	{
		"id": "THE_XIFU",
		"name": "THE XIFU",
		"difficulty": "Extreme",
		"desc": "Hit 30 targets, 90% accuracy",
		"hits": 30,
		"time": 45.0,
		"accuracy": 90.0,
		"fruits": ["apple", "orange", "pear", "watermelon", "melon", "coconut"],
		"color": Color(0.9, 0.2, 0.2)
	}
]

func get_rank(id: String) -> Dictionary:
	for r in RANKS:
		if r.id == id:
			return r
	return RANKS[0]

func get_all_ranks() -> Array:
	return RANKS

func is_unlocked(id: String) -> bool:
	var unlocked = GameManager.player_data.get("unlocked_ranks", ["THE_COOK"])
	return id in unlocked

func unlock_next(current_id: String) -> void:
	var unlocked = GameManager.player_data.get("unlocked_ranks", ["THE_COOK"])
	var found = false
	for r in RANKS:
		if found and r.id not in unlocked:
			unlocked.append(r.id)
			GameManager.player_data.unlocked_ranks = unlocked
			SaveManager.save_game()
			return
		if r.id == current_id:
			found = true
