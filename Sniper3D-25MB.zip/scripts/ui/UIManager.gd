extends Node

## UI Manager - Autoload
## Handles scene transitions and global UI state.

signal transition_started
signal transition_finished

var current_ui_scene: Node = null

func _ready() -> void:
	print("[UIManager] Ready")

func change_ui_scene(path: String, transition: bool = true) -> void:
	if transition:
		transition_started.emit()
		# Simple fade can be added later with ColorRect
		await get_tree().create_timer(0.15).timeout
	
	# Remove previous
	if current_ui_scene and is_instance_valid(current_ui_scene):
		current_ui_scene.queue_free()
		current_ui_scene = null
	
	var packed = load(path)
	if packed:
		current_ui_scene = packed.instantiate()
		get_tree().root.add_child(current_ui_scene)
	else:
		push_error("[UIManager] Failed to load UI scene: " + path)
	
	if transition:
		await get_tree().create_timer(0.1).timeout
		transition_finished.emit()

func show_home() -> void:
	GameManager.change_state(GameManager.GameState.HOME)
	change_ui_scene("res://scenes/menus/home.tscn")

func show_settings() -> void:
	GameManager.change_state(GameManager.GameState.SETTINGS)
	change_ui_scene("res://scenes/menus/settings.tscn")

func show_result(result: Dictionary) -> void:
	GameManager.change_state(GameManager.GameState.RESULT)
	# Result scene can read from GameManager
	change_ui_scene("res://scenes/menus/result.tscn")
