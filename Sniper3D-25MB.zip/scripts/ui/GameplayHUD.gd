extends CanvasLayer

@onready var objective: Label = $TopBar/Objective
@onready var ammo_label: Label = $TopBar/Ammo
@onready var score_label: Label = $ScoreLabel
@onready var timer_label: Label = $TimerLabel
@onready var scope_btn: Button = $ScopeBtn
@onready var shoot_btn: Button = $ShootBtn
@onready var reload_btn: Button = $ReloadBtn
@onready var crosshair: Label = $Crosshair

var ammo: int = 5
var max_ammo: int = 15
var time_left: float = 90.0
var is_scoped: bool = false
var player: PlayerController = null
var spawner: FruitSpawner = null
var rank_mgr: RankManager = null
var target_hits: int = 10
var current_rank_id: String = "THE_COOK"

func _ready() -> void:
	scope_btn.pressed.connect(_on_scope)
	shoot_btn.pressed.connect(_on_shoot)
	reload_btn.pressed.connect(_on_reload)
	GameManager.score_updated.connect(_on_score_updated)
	
	AudioManager.play_ambient("wind")
	
	await get_tree().process_frame
	player = get_tree().get_first_node_in_group("player") as PlayerController
	
	# Create spawner
	spawner = FruitSpawner.new()
	spawner.name = "FruitSpawner"
	get_parent().add_child(spawner)
	
	rank_mgr = RankManager.new()
	
	if player and player.weapon:
		player.weapon.ammo_changed.connect(_on_ammo_changed)
		player.weapon.fired.connect(_on_weapon_fired)
		ammo = player.weapon.current_ammo
		max_ammo = player.weapon.weapon_data.magazine_size
		_update_ammo()
	
	_setup_mode()
	_update_timer_display()

func _setup_mode() -> void:
	match GameManager.current_mode:
		GameManager.GameMode.TIME:
			time_left = 90.0
			objective.text = "MODE WAKTU — Tembak sebanyak mungkin!"
			spawner.spawn_sequence(["apple", "orange", "pear"], 8)
		GameManager.GameMode.FREE:
			timer_label.visible = false
			objective.text = "MODE BEBAS — Latihan bebas"
			spawner.spawn_sequence(["apple", "orange", "watermelon"], 6)
		GameManager.GameMode.RANK:
			current_rank_id = GameManager.current_rank if GameManager.current_rank != "" else "THE_COOK"
			var r = rank_mgr.get_rank(current_rank_id)
			time_left = r.time
			target_hits = r.hits
			objective.text = "%s — %s" % [r.name, r.desc]
			var types: Array[String] = []
			for t in r.fruits:
				types.append(t)
			spawner.spawn_sequence(types, mini(r.hits, 12))
		_:
			spawner.spawn_fruit("apple")

func _process(delta: float) -> void:
	if GameManager.current_state != GameManager.GameState.PLAYING:
		return
	if GameManager.current_mode == GameManager.GameMode.FREE:
		return
	time_left -= delta
	if time_left <= 0.0:
		time_left = 0.0
		_end_mission()
	_update_timer_display()
	
	# Check rank complete
	if GameManager.current_mode == GameManager.GameMode.RANK:
		if GameManager.session_hits >= target_hits:
			_end_mission()

func _update_ammo() -> void:
	ammo_label.text = "%d / %d" % [ammo, max_ammo]

func _update_timer_display() -> void:
	var m = int(time_left) / 60
	var s = int(time_left) % 60
	timer_label.text = "%02d:%02d" % [m, s]

func _on_score_updated(score: int) -> void:
	score_label.text = "SCORE: %d" % score

func _on_ammo_changed(current: int, reserve: int) -> void:
	ammo = current
	if player and player.weapon:
		max_ammo = player.weapon.weapon_data.magazine_size
	_update_ammo()

func _on_weapon_fired() -> void:
	_perform_hit_check()

func _on_scope() -> void:
	is_scoped = not is_scoped
	crosshair.visible = not is_scoped
	if player:
		player.set_scoped(is_scoped)

func _on_shoot() -> void:
	if player:
		player.fire()

func _on_reload() -> void:
	if player:
		player.reload()

func _perform_hit_check() -> void:
	var cam = get_viewport().get_camera_3d()
	if not cam:
		return
	var from = cam.global_position
	var to = from + (-cam.global_transform.basis.z * 250.0)
	var space = cam.get_world_3d().direct_space_state
	var query = PhysicsRayQueryParameters3D.create(from, to)
	query.collision_mask = 2
	var result = space.intersect_ray(query)
	
	if result:
		GameManager.register_hit(true)
		GameManager.add_score(100)
		AudioManager.play_impact("fruit_hit")
		AudioManager.play_ui("hit_marker")
		var body = result.collider
		if body is RigidBody3D:
			var dir = (result.position - from).normalized()
			body.apply_impulse(dir * 5.5)
			if body.has_method("apply_bullet_impact"):
				body.apply_bullet_impact(dir, 5.5)
		# Respawn if needed
		if spawner and spawner.get_active_count() < 3:
			var types = ["apple", "orange", "pear"]
			spawner.spawn_fruit(types[randi() % types.size()])
	else:
		GameManager.register_miss()
		AudioManager.play_ui("miss") if false else null

func _end_mission() -> void:
	var result = GameManager.end_mission()
	if GameManager.current_mode == GameManager.GameMode.RANK:
		if result.accuracy >= rank_mgr.get_rank(current_rank_id).accuracy:
			rank_mgr.unlock_next(current_rank_id)
			AudioManager.play_ui("perfect_hit")
	AudioManager.stop_ambient()
	# Simple result: back to home with score in objective for now
	get_tree().change_scene_to_file("res://scenes/menus/home.tscn")
