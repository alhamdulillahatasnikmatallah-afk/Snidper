extends Control

@onready var name_label: Label = $TopBar/PlayerInfo/PlayerText/NameLabel
@onready var level_label: Label = $TopBar/PlayerInfo/PlayerText/LevelLabel
@onready var coins_label: Label = $TopBar/Currencies/Coins
@onready var gems_label: Label = $TopBar/Currencies/Gems
@onready var energy_label: Label = $TopBar/Currencies/Energy

@onready var btn_play_time: Button = $ModeCards/CardTime/VBox/BtnPlayTime
@onready var btn_play_free: Button = $ModeCards/CardFree/VBox/BtnPlayFree
@onready var btn_play_rank: Button = $ModeCards/CardRank/VBox/BtnPlayRank
@onready var btn_quick: Button = $QuickStart

func _ready() -> void:
	_update_player_ui()
	_connect_buttons()
	AudioManager.play_ui("menu_open")

func _update_player_ui() -> void:
	var d = GameManager.player_data
	name_label.text = d.name
	level_label.text = "Lv. %d" % d.level
	coins_label.text = "%s" % _format_number(d.coins)
	gems_label.text = str(d.gems)
	energy_label.text = "%d/%d" % [d.energy, d.max_energy]

func _format_number(n: int) -> String:
	var s := str(n)
	var result := ""
	var count := 0
	for i in range(s.length() - 1, -1, -1):
		if count > 0 and count % 3 == 0:
			result = "," + result
		result = s[i] + result
		count += 1
	return result

func _connect_buttons() -> void:
	btn_play_time.pressed.connect(_on_play_time)
	btn_play_free.pressed.connect(_on_play_free)
	btn_play_rank.pressed.connect(_on_play_rank)
	btn_quick.pressed.connect(_on_quick_start)
	
	$LeftNav/BtnHome.pressed.connect(func(): AudioManager.play_ui("button_click"))
	$LeftNav/BtnMode.pressed.connect(func(): AudioManager.play_ui("button_click"))
	$LeftNav/BtnWeapon.pressed.connect(func(): AudioManager.play_ui("button_click"))
	$LeftNav/BtnRank.pressed.connect(_on_rank)
	$LeftNav/BtnAchieve.pressed.connect(func(): AudioManager.play_ui("button_click"))
	$LeftNav/BtnDaily.pressed.connect(func(): AudioManager.play_ui("button_click"))

func _on_play_time() -> void:
	AudioManager.play_ui("button_click")
	GameManager.start_mode(GameManager.GameMode.TIME)
	get_tree().change_scene_to_file("res://scenes/gameplay/range.tscn")

func _on_play_free() -> void:
	AudioManager.play_ui("button_click")
	GameManager.start_mode(GameManager.GameMode.FREE)
	get_tree().change_scene_to_file("res://scenes/gameplay/range.tscn")

func _on_play_rank() -> void:
	AudioManager.play_ui("button_click")
	# Start with first unlocked rank
	var unlocked = GameManager.player_data.get("unlocked_ranks", ["THE_COOK"])
	var rank_id = unlocked[unlocked.size() - 1] if unlocked.size() > 0 else "THE_COOK"
	GameManager.start_mode(GameManager.GameMode.RANK, rank_id)
	get_tree().change_scene_to_file("res://scenes/gameplay/range.tscn")

func _on_quick_start() -> void:
	AudioManager.play_ui("button_click")
	GameManager.start_mode(GameManager.GameMode.TIME)
	get_tree().change_scene_to_file("res://scenes/gameplay/range.tscn")

func _on_rank() -> void:
	AudioManager.play_ui("button_click")
	# For now just start rank mode
	_on_play_rank()
