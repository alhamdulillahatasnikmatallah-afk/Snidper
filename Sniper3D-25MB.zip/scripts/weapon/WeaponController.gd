extends Node3D
class_name WeaponController

## Modular sniper weapon controller with state machine.

enum State {
	IDLE,
	AIMING,
	SCOPED,
	FIRING,
	RECOILING,
	RELOADING,
	BOLT_ACTION,
	DISABLED
}

signal state_changed(new_state: State)
signal fired()
signal reloaded()
signal ammo_changed(current: int, reserve: int)
signal dry_fired()

@export var weapon_data: WeaponData

var muzzle: Marker3D = null
var current_state: State = State.IDLE
var current_ammo: int = 5
var reserve_ammo: int = 30
var is_chambered: bool = true
var can_fire: bool = true

var recoil_offset: Vector3 = Vector3.ZERO
var recoil_rotation: Vector3 = Vector3.ZERO
var target_recoil_offset: Vector3 = Vector3.ZERO
var target_recoil_rotation: Vector3 = Vector3.ZERO

var base_position: Vector3
var base_rotation: Vector3

func _ready() -> void:
	if weapon_data == null:
		weapon_data = WeaponData.new()
	
	current_ammo = weapon_data.magazine_size
	reserve_ammo = weapon_data.reserve_ammo
	base_position = position
	base_rotation = rotation_degrees
	
	# Always create muzzle safely
	if has_node("Muzzle"):
		muzzle = $Muzzle
	else:
		muzzle = Marker3D.new()
		muzzle.name = "Muzzle"
		muzzle.position = Vector3(0, 0.05, -0.7)
		add_child(muzzle)

func _process(delta: float) -> void:
	_update_recoil(delta)
	_update_idle_sway(delta)

func set_state(new_state: State) -> void:
	if current_state == new_state:
		return
	if current_state == State.RELOADING and new_state != State.IDLE:
		return
	if current_state == State.DISABLED:
		return
	current_state = new_state
	state_changed.emit(new_state)

func try_fire() -> bool:
	if not can_fire:
		return false
	if current_state in [State.RELOADING, State.BOLT_ACTION, State.DISABLED]:
		return false
	if current_ammo <= 0 or not is_chambered:
		_dry_fire()
		return false
	_do_fire()
	return true

func _do_fire() -> void:
	set_state(State.FIRING)
	current_ammo -= 1
	is_chambered = false
	ammo_changed.emit(current_ammo, reserve_ammo)
	
	var vert = weapon_data.recoil_vertical * randf_range(0.85, 1.15)
	var horiz = weapon_data.recoil_horizontal * randf_range(-1.0, 1.0)
	target_recoil_offset = Vector3(0, 0, 0.04)
	target_recoil_rotation = Vector3(-vert, horiz, 0)
	
	fired.emit()
	AudioManager.play_weapon("sniper_shot")
	
	if weapon_data.bolt_action:
		await get_tree().create_timer(0.15).timeout
		_start_bolt_action()
	else:
		is_chambered = true
		set_state(State.IDLE)

func _dry_fire() -> void:
	AudioManager.play_weapon("dry_fire")
	dry_fired.emit()

func _start_bolt_action() -> void:
	set_state(State.BOLT_ACTION)
	AudioManager.play_weapon("bolt_action")
	await get_tree().create_timer(0.55).timeout
	is_chambered = true
	set_state(State.IDLE)

func start_reload() -> void:
	if current_state == State.RELOADING:
		return
	if current_ammo >= weapon_data.magazine_size:
		return
	if reserve_ammo <= 0:
		return
	
	set_state(State.RELOADING)
	AudioManager.play_weapon("reload")
	
	await get_tree().create_timer(weapon_data.reload_time).timeout
	
	var needed = weapon_data.magazine_size - current_ammo
	var take = mini(needed, reserve_ammo)
	current_ammo += take
	reserve_ammo -= take
	is_chambered = true
	ammo_changed.emit(current_ammo, reserve_ammo)
	
	reloaded.emit()
	set_state(State.IDLE)

func _update_recoil(delta: float) -> void:
	target_recoil_offset = target_recoil_offset.lerp(Vector3.ZERO, delta * weapon_data.recoil_recovery)
	target_recoil_rotation = target_recoil_rotation.lerp(Vector3.ZERO, delta * weapon_data.recoil_recovery)
	
	recoil_offset = recoil_offset.lerp(target_recoil_offset, delta * 18.0)
	recoil_rotation = recoil_rotation.lerp(target_recoil_rotation, delta * 18.0)
	
	position = base_position + recoil_offset
	rotation_degrees = base_rotation + recoil_rotation

func _update_idle_sway(delta: float) -> void:
	if current_state in [State.FIRING, State.RECOILING, State.RELOADING, State.BOLT_ACTION]:
		return
	var t = Time.get_ticks_msec() / 1000.0
	var sway = Vector3(sin(t * 1.1) * 0.0015, cos(t * 0.9) * 0.002, 0)
	position = base_position + recoil_offset + sway

func get_muzzle_position() -> Vector3:
	return muzzle.global_position if muzzle else global_position

func get_muzzle_direction() -> Vector3:
	return -global_transform.basis.z
