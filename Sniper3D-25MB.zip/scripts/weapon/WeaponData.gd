extends Resource
class_name WeaponData

@export var id: String = "sniper_basic"
@export var display_name: String = "Sniper Rifle"
@export var damage: float = 100.0
@export var accuracy: float = 0.92
@export var stability: float = 0.75
@export var reload_time: float = 2.4
@export var magazine_size: int = 5
@export var reserve_ammo: int = 30
@export var fire_rate: float = 0.8
@export var zoom_levels: Array[float] = [1.0, 2.0, 4.0, 8.0]
@export var recoil_vertical: float = 2.8
@export var recoil_horizontal: float = 0.6
@export var recoil_recovery: float = 8.0
@export var weight: float = 1.0
@export var bolt_action: bool = true
@export var description: String = "Bolt-action precision rifle"
