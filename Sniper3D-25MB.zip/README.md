# SNIPER 3D — Godot 4.3 Mobile

First-person sniper fruit-shooting game for Android (ARMv7 + ARM64).

## What is included now

### Gameplay
- 3 Modes: **Mode Waktu**, **Mode Bebas**, **Mode Rank**
- 5 Ranks: THE COOK → THE CHICKEN → THE COOL → THE MASTER → THE XIFU
- Fruit types: Apple, Orange, Pear, Watermelon (breakable), Melon, Coconut
- Physics impulse + squash/break reaction
- Scope (smooth FOV 1x–8x), Recoil, Bolt-action, Reload
- Score, Combo, Accuracy, Timer, Ammo HUD
- Touch look + on-screen buttons

### Assets
- Barrett sniper (FBX/3DS + texture)
- Rigged Hand + textures
- Male character (high-poly OBJ)
- Grass textures + .blend
- Morning scene .blend
- Weapon / Impact / UI / Scope sounds
- Wind + Birds ambient loops

### Systems
- GameManager, SaveManager, QualityManager, AudioManager
- FruitSpawner, RankManager, WeaponController, ScopeController
- GitHub Actions ready for APK build

## How to build
1. Push to GitHub
2. Actions → "Build Sniper 3D Android" → Run
3. Download APK artifact

## Notes
- .blend files need export to .glb in Blender for best Godot import
- Ambient wind/birds are procedural placeholders (replace with real recordings if desired)
- High-poly Male.OBJ is for preview only — not for gameplay FPS
